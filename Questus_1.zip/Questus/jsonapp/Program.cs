﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;


namespace JsoN

{
    public class Scene
    {
        public string variant_1 { get; set; }
        public string variant_2 { get; set; }
        public string variant_3 { get; set; }

        public Scene() { }

        public Scene(string _1, string _2, string _3)
        {
            variant_1 = _1;
            variant_2 = _2;
            variant_3 = _3;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Scene> ListScene = new List<Scene>();


            //Scene point = Scene("Повернуть назад", "Пойти поесть", "Пойти вперёд");
            //string JsonObject = JsonConvert.SerializeObjekt(point);
            //Console.WriteLine(JsonObject);
            //Scene point3 = JsonConvert.DeserializeObject<Scene>(JsonObject);
            //Console.WriteLine(point3.variant_1, point3.variant_2, point3.variant_3);

            //запись объектов в json

            Scene point0 = new Scene("Повернуть назад", "Пойти поесть", "Пойти вперёд");
            ListScene.Add(point0);

            FileWriteAllText("input.json", string.Empty);
            for (int i = 0; i < ListScene.Count; i++)
              FileAppendAllText("input.json", JsonConvert.SerializeObject(ListScene[i]));

            //чтение файла

            JsonTextReader reader = new JsonTextReader(new StreamReader("input.json"));
            reader.SupportMultipleContent = true;
            while (true)
            {
                if (!reader.Read())
                {
                    break;
                }

                JsonSerializer serializer = new JsonSerializer();

                Scene temp_point = serializer.Deserialize<Scene>(reader);
                ListScene.Add(temp_point);
            }

            //Вывод на экран списка
            for (int i = 0; i < ListScene.Count; i++)
                Console.WriteLine(ListScene[i].variant_1 + "" + ListScene[i].variant_2 + "" + ListScene[i].variant_3 + "");
            Console.ReadKey();
        }

    }
}